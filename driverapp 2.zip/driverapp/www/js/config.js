/*Driver App Configuration*/

var krms_driver_config ={	
	'ApiUrl':"https://foodsquire.com/driver/api",	
	'DialogDefaultTitle':"DriverApp",	
	'PushProjectID':"491618252405",
	'APIHasKey':"1234567890"
};
